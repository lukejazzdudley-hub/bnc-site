# Cadence media kit

Cadence is a mobile songwriting workspace for artists who want to carry an idea from a first line or voice memo through lyrics, beat looping, recorded takes and a demo without scattering the work across apps. The artist writes and performs the song; Cadence does not generate it.

Available on [iOS](https://apps.apple.com/gb/app/cadence-lyrics-rhymes/id6778554520) and [Android](https://play.google.com/store/apps/details?id=io.cadenceapp.mobile). It is free to download with optional in-app purchases.

## In this kit

- `visuals/`: six editorial compositions in landscape, portrait, square and story formats.
- `phones/`: five transparent handset renders for a publication's own layout.
- `native-screenshots/`: seven original iPhone captures showing the real interface.
- `brand/`: two transparent Cadence marks. Use the unbounded mark in preference to a square app icon as a wordmark.
- `video/product-demo-excerpts-silent.mp4`: a silent montage of separate real-device excerpts. It is not a continuous-song recording.

The rendered phones and layouts use real app captures. The Draft screen and the lyric/loop screens show distinct demonstration songs, not one continuous session. The video was captured in TestFlight, so please do not describe it as a recording of the released build. No music audio is included or licensed with this pack.

Please credit supplied artwork to **Cadence / Brand Name Changes Ltd**. For a fresh released-build walkthrough, review access, an interview or image questions, contact **hello@brandnamechanges.com**.

Website: https://brandnamechanges.com/cadence/
