# Cadence press release

**Cadence launches on iOS and Android, keeping a song together from first line to recorded demo**

**London, 23 September 2026**

Songwriters often capture a line in Notes, save a melody in Voice Memos, play a beat elsewhere and rebuild the idea in recording software. The obstacle is not a shortage of ideas; it is the loss of momentum between those places. Cadence brings those stages into one mobile workspace for lyric-led artists.

An artist can import an existing lyric or recording, develop words with pronunciation-based rhyme tools, loop a beat while writing, record takes against it, arrange a timed draft and finish an exported demo in the app's multitrack workspace. Lyrics, beat, takes and arrangement remain attached to the same song.

For working artists, the aim is to reopen the song and continue rather than search for the note, beat or take that belongs to it. For someone just beginning to write, a single line is enough to start. Cadence's rhyme tools show relationships in the lyric editor and offer perfect, slant, multisyllable, multi-word and assonance suggestions. The artist chooses every word. Recording transcription is available for turning an existing memo into an editable draft. Cadence supports the writer's decisions; it does not generate the song for them.

Cadence is available on the [App Store](https://apps.apple.com/gb/app/cadence-lyrics-rhymes/id6778554520) and [Google Play](https://play.google.com/store/apps/details?id=io.cadenceapp.mobile). The app is free to download with optional in-app purchases. More information is at [brandnamechanges.com/cadence](https://brandnamechanges.com/cadence/).

**For editors:** the visual press kit contains real product screenshots, designed Onyx press art and a short silent real-device excerpt montage. We can arrange a hands-on walkthrough of one owned song from first line to recorded draft, and offer review access or an interview. The supplied montage combines distinct moments and should not be described as a continuous-song recording.

**Media contact:** hello@brandnamechanges.com

**About Brand Name Changes Ltd:** Brand Name Changes Ltd develops Cadence, a mobile workspace for writing, recording and finishing songs.
